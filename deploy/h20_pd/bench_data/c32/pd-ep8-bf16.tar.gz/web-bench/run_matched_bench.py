import os,json,time,threading,concurrent.futures,statistics,traceback
from pathlib import Path
s=Path(__file__).resolve().parent
os.environ.update(BENCH_OUTPUT=str(s/'results'),OUTPUT_TOKENS='2048',BENCH_URL='http://10.245.231.151:19500')
from matched_client import collect,client,write,quantile
root=s/'results';root.mkdir(exist_ok=True)
def status(phase,**kw):write(s/'benchmark-status.json',dict(phase=phase,time=time.time(),**kw))
def workers():
 with client() as c:return c.get(os.environ['BENCH_URL']+'/workers',timeout=10).json()
def wait_idle():
 deadline=time.monotonic()+180;stable=0;observations=[]
 while time.monotonic()<deadline:
  data=workers();ok=True;count=0
  for w in data.get('workers',[]):
   loads=w.get('engine_load',{}).get('loads',[])
   if w['worker_type']=='decode':count=len(loads)
   if not loads or any(v['num_running_reqs'] or v['num_waiting_reqs'] for v in loads):ok=False
  ok=ok and count==8
  observations.append({'time':time.time(),'idle':ok,'state':data})
  stable=stable+1 if ok else 0
  if stable>=3:return observations
  time.sleep(1)
 raise TimeoutError('All P/D ranks must become idle before the next batch')
def batch(name,c=32):
 dest=root/name;dest.mkdir(exist_ok=False)
 write(dest/'idle-before.json',wait_idle())
 stop=threading.Event();barrier=threading.Barrier(c)
 def watch():
  with (dest/'workers.jsonl').open('w') as f:
   while not stop.is_set():
    try:v=workers()
    except Exception as e:v={'error':repr(e)}
    f.write(json.dumps({'time':time.time(),'state':v})+'\n');f.flush();stop.wait(.2)
 th=threading.Thread(target=watch);th.start()
 try:
  with concurrent.futures.ThreadPoolExecutor(max_workers=c) as pool:
   rows=list(pool.map(lambda i:collect(i,inputs[i],barrier,dest/f'request-{i}.json'),range(c)))
 finally:stop.set();th.join()
 failures=[(x['index'],x.get('error')) for x in rows if not x['success']]
 if failures:raise RuntimeError(failures)
 first=min(x['events'][0][0] for x in rows);last=max(x['events'][-1][0] for x in rows)
 out={'round':name,'requests':c,'input_tokens':128928,'output_tokens':2048,'output_window_s':last-first,'output_tps':c*2048/(last-first),'per_gpu_output_tps':c*2048/(last-first)/8,'cached_tokens':[x['meta'].get('cached_tokens') for x in rows]}
 for k in ['ttft_s','tpot_ms']:
  v=[x[k] for x in rows];out.update({k+'_mean':statistics.mean(v),k+'_p50':quantile(v,.5),k+'_p90':quantile(v,.9)})
 out['tps_user_p50']=1000/out['tpot_ms_p50']
 write(dest/'summary.json',out)
 return out
try:
 status('waiting_services')
 for _ in range(720):
  try:
   w=workers()['workers']
   if (len(w)==2 and all(x.get('is_healthy') and x.get('status')=='ready' and x.get('engine_load',{}).get('loads') for x in w)
       and all(len(x['engine_load']['loads'])==8 for x in w if x['worker_type']=='decode')):break
  except Exception:pass
  time.sleep(5)
 else:raise TimeoutError('PD startup exceeded one hour')
 inputs=json.loads((s/'inputs.json').read_text());assert len(inputs)==64 and all(len(x)==128928 for x in inputs)
 write(root/'ready-workers.json',workers())
 status('priming_shared_prefix');batch('prime-shared-prefix',1)
 result=[]
 for concurrency in (32,64):
  status('warming',concurrency=concurrency);batch(f'warm-c{concurrency}',concurrency)
  for i in range(1,4):
   status('measuring',concurrency=concurrency,round=i)
   result.append(batch(f'c{concurrency}-round-{i}',concurrency));write(root/'SUMMARY.json',result)
 status('complete',summaries=result)
except BaseException as e:
 status('failed',error=repr(e),traceback=traceback.format_exc());raise
